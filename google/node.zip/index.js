exports.handler = (req, res) => {
  res.status(200).send("Cold start test completed");
};
