def handler(request):
    return "Python cold start test", 200