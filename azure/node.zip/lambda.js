exports.handler = () => {
  return {
    statusCode: 200,
    body: "Cold start test completed",
  };
};
